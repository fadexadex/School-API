//addition of a two number program
//Write me a code that
const Ichange = 500;

console.log(`The number is ${Ichange}`);
